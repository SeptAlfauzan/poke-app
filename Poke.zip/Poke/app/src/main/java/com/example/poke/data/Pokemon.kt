package com.example.poke.data

data class Pokemon(
    val name: String,
    val imageUrl: String,
)
