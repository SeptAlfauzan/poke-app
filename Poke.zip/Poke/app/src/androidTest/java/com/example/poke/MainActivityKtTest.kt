package com.example.poke

import androidx.activity.ComponentActivity
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithTag
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performScrollToIndex
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.ComposeNavigator
import androidx.navigation.testing.TestNavHostController
import com.example.poke.config.ViewModelFactory
import com.example.poke.data.DummyData
import com.example.poke.data.GetPokemonsResponse
import com.example.poke.data.Repository
import com.example.poke.ui.common.UiState
import com.example.poke.ui.navigation.Screen
import com.example.poke.ui.theme.PokeTheme
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.Mockito.mock
import org.mockito.MockitoAnnotations

internal class MainActivityKtTest{
    @get:Rule
    val composeTestRule = createAndroidComposeRule<ComponentActivity>()
    private lateinit var navController: TestNavHostController
//
    @Mock
    private lateinit var repository: Repository

//    @Before
    fun setup(){
//        MockitoAnnotations.openMocks(this)

        composeTestRule.setContent {
            PokeTheme {
                navController = TestNavHostController(LocalContext.current)
                navController.navigatorProvider.addNavigator(ComposeNavigator())
                PokeApp(
                    navController = navController,
                    pokemonViewModel = viewModel(
                        factory = ViewModelFactory(repository)
                    )
                )
            }
        }
    }

    @Test
    fun verify_startDestination(){
        val currentRoute = navController.currentBackStackEntry?.destination?.route
        assertEquals(Screen.Home.route, currentRoute)
    }

    @Test
    fun verify_home_isEmpty() = runTest{
        val expected = DummyData.getEmpty()
        repository = mock(Repository::class.java)
        Mockito.`when`(repository.getAllPokemons()).thenReturn(flowOf(expected))

        composeTestRule.setContent {
            PokeTheme {
                navController = TestNavHostController(LocalContext.current)
                navController.navigatorProvider.addNavigator(ComposeNavigator())
                PokeApp(
                    navController = navController,
                    pokemonViewModel = viewModel(
                        factory = ViewModelFactory(repository)
                    )
                )
            }
        }
    }

    @Test
    fun verify_home_isNotEmpty(){

    }

    @Test
    fun verify_favorite_isEmpty(){

    }

    @Test
    fun verify_favorite_isNotEmpty(){

    }

}